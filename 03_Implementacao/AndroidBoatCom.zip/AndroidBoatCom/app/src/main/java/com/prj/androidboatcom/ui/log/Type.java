package com.prj.androidboatcom.ui.log;

public enum Type {

    ONCREATE,
    SEP,
    BASE,
    SR,
    SCREEN,
    CONTROL,
    LOCAL,
    MONITOR
}
